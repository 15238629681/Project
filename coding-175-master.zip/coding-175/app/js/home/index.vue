<template>
    <div :class="$style.home">
        <h1>Home2</h1>
    </div>
</template>

<script>
export default {
}
</script>

<style lang="scss" module>
  @import '../../css/reset.scss';
  .home{
    color: red;
    font-size: 80px;
  }
</style>
